Awave Studio, ReadMe file                Copyright 2000, 2017, FMJ-Software
---------------------------------------------------------------------------
This software is distributed as Shareware with a 30 day free trial period.
The latest version is found here: http://www.fmjsoft.com/


Requirements:

  - Windows 10 / 8 / 7 / Vista / XP+SP3

Optional:

  - Several audio compression codec add-ons - see our web site for details.

Installation:

  - Run Setup.exe and follow the instructions.
  - Go through the Help menu; especially the 'Using Awave Studio' section.

Uninstallation:

  - Use the Windows control panel's 'Add/Remove program' feature.

Support:

  - First review the F.A.Q. section of help file!
  - Next, see our www site, http://www.fmjsoft.com/


Have Fun!
